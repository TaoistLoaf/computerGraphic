/** CSci-4611 Example Code
 * Copyright 2023+ Regents of the University of Minnesota
 * Please do not distribute beyond the CSci-4611 course
 */

import { ExampleApp } from './ExampleApp'

const app = new ExampleApp();
app.start();